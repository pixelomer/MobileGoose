#import <UIKit/UIKit.h>
#import <MobileGoose.h>

@interface @@CLASSNAME@@ : NSObject<MGMod>
@property (nonatomic, weak) MGGooseView *goose;
@end
